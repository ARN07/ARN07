var Person = {
			nama 	: "Aulia Rahman",
			age	 	: "20th",
			gender	: "Laki-Laki",
			interest: "",
			bio		: ""
		}